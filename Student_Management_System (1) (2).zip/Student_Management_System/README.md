# Student Management System (Java)

A console-based Student Management System created for **Module 02 – Methods, Collections & Exceptions**.

## Features
- Add, view, search, update and delete student records
- Uses `ArrayList`, `HashMap` and `HashSet`
- Demonstrates methods, parameter passing, method overloading and scope
- Handles invalid input and missing student records with exceptions
- Reads and writes student records to `students.txt`

## Requirements
- Java JDK 17 or later

## How to run
Open a terminal in the project folder and run:

```bash
javac -d out src/main/java/StudentManagementSystem.java
java -cp out StudentManagementSystem
```

The program creates `students.txt` in the current working directory when records are saved.

## Collections used
| Collection | Purpose |
|---|---|
| ArrayList | Stores student records in insertion order |
| HashMap | Finds a student quickly using student ID |
| HashSet | Prevents duplicate email addresses |

## Java concepts demonstrated
- Methods and parameter passing
- Method overloading (`displayMessage`)
- Local and instance variables / scope
- `try-catch`, `throw`, `throws`
- Custom exception (`StudentNotFoundException`)
- File reading and writing using buffered streams and try-with-resources

## Project structure
```text
Student_Management_System/
├── README.md
├── .gitignore
└── src/
    └── main/
        └── java/
            └── StudentManagementSystem.java
```

## Author
Deepika B.
