import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Student Management System
 * Demonstrates Java methods, collections, exception handling and file I/O.
 */
public class StudentManagementSystem {
    private static final String DATA_FILE = "students.txt";

    // ArrayList stores the student records in insertion order.
    private final List<Student> students = new ArrayList<>();

    // HashMap provides quick lookup by student ID.
    private final Map<Integer, Student> studentsById = new HashMap<>();

    // HashSet ensures that email addresses remain unique.
    private final Set<String> registeredEmails = new HashSet<>();

    private final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        StudentManagementSystem app = new StudentManagementSystem();
        app.loadStudents();
        app.run();
    }

    private void run() {
        boolean running = true;
        System.out.println("==================================");
        System.out.println("     STUDENT MANAGEMENT SYSTEM");
        System.out.println("==================================");

        while (running) {
            printMenu();
            int choice = readInt("Enter your choice: ");

            try {
                switch (choice) {
                    case 1 -> addStudent();
                    case 2 -> viewAllStudents();
                    case 3 -> searchStudent();
                    case 4 -> updateStudent();
                    case 5 -> deleteStudent();
                    case 6 -> {
                        saveStudents();
                        System.out.println("Data saved. Goodbye!");
                        running = false;
                    }
                    default -> System.out.println("Please enter a number from 1 to 6.");
                }
            } catch (IllegalArgumentException | StudentNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (IOException e) {
                System.out.println("File error: " + e.getMessage());
            }
            System.out.println();
        }
    }

    private void printMenu() {
        System.out.println("\n1. Add Student");
        System.out.println("2. View All Students");
        System.out.println("3. Search Student");
        System.out.println("4. Update Student");
        System.out.println("5. Delete Student");
        System.out.println("6. Save and Exit");
    }

    // Method overloading: same method name with different parameters.
    private void displayMessage(String message) {
        System.out.println(message);
    }

    private void displayMessage(String title, String message) {
        System.out.println(title + ": " + message);
    }

    private void addStudent() throws IOException {
        int id = readInt("Student ID: ");
        String name = readNonEmpty("Student name: ");
        String email = readNonEmpty("Email: ").toLowerCase(Locale.ROOT);
        double marks = readDouble("Marks (0-100): ");

        validateStudent(id, name, email, marks);

        if (studentsById.containsKey(id)) {
            throw new IllegalArgumentException("Student ID already exists.");
        }
        if (registeredEmails.contains(email)) {
            throw new IllegalArgumentException("Email is already registered.");
        }

        Student student = new Student(id, name, email, marks);
        students.add(student);
        studentsById.put(id, student);
        registeredEmails.add(email);

        saveStudents();
        displayMessage("Success", "Student added successfully.");
    }

    private void viewAllStudents() {
        if (students.isEmpty()) {
            displayMessage("No student records found.");
            return;
        }

        System.out.println("\nID\tName\t\tEmail\t\t\tMarks");
        System.out.println("--------------------------------------------------------------");
        for (Student student : students) {
            System.out.println(student);
        }
    }

    private void searchStudent() throws StudentNotFoundException {
        int id = readInt("Enter student ID to search: ");
        Student student = findStudent(id);
        displayMessage("Student Found", student.toString());
    }

    private void updateStudent() throws IOException, StudentNotFoundException {
        int id = readInt("Enter student ID to update: ");
        Student student = findStudent(id);

        System.out.println("Leave a field blank to keep its current value.");
        String newName = readLine("New name [" + student.getName() + "]: ");
        String newEmail = readLine("New email [" + student.getEmail() + "]: ");
        String newMarksText = readLine("New marks [" + student.getMarks() + "]: ");

        String name = newName.isBlank() ? student.getName() : newName.trim();
        String email = newEmail.isBlank()
                ? student.getEmail() : newEmail.trim().toLowerCase(Locale.ROOT);
        double marks = newMarksText.isBlank()
                ? student.getMarks() : parseMarks(newMarksText);

        validateStudent(id, name, email, marks);

        Student emailOwner = findByEmail(email);
        if (emailOwner != null && emailOwner.getId() != id) {
            throw new IllegalArgumentException("Email belongs to another student.");
        }

        registeredEmails.remove(student.getEmail());
        student.setName(name);
        student.setEmail(email);
        student.setMarks(marks);
        registeredEmails.add(email);

        saveStudents();
        displayMessage("Success", "Student record updated.");
    }

    private void deleteStudent() throws IOException, StudentNotFoundException {
        int id = readInt("Enter student ID to delete: ");
        Student student = findStudent(id);

        students.remove(student);
        studentsById.remove(id);
        registeredEmails.remove(student.getEmail());

        saveStudents();
        displayMessage("Success", "Student record deleted.");
    }

    private Student findStudent(int id) throws StudentNotFoundException {
        Student student = studentsById.get(id);
        if (student == null) {
            throw new StudentNotFoundException("No student found with ID " + id);
        }
        return student;
    }

    private Student findByEmail(String email) {
        for (Student student : students) {
            if (student.getEmail().equalsIgnoreCase(email)) {
                return student;
            }
        }
        return null;
    }

    // throw is used to raise an exception when input is invalid.
    private void validateStudent(int id, String name, String email, double marks) {
        if (id <= 0) {
            throw new IllegalArgumentException("Student ID must be positive.");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            throw new IllegalArgumentException("Enter a valid email address.");
        }
        if (marks < 0 || marks > 100) {
            throw new IllegalArgumentException("Marks must be between 0 and 100.");
        }
    }

    private int readInt(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private double readDouble(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Double.parseDouble(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private double parseMarks(String value) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Marks must be a valid number.");
        }
    }

    private String readNonEmpty(String prompt) {
        while (true) {
            String value = readLine(prompt).trim();
            if (!value.isEmpty()) return value;
            System.out.println("This field cannot be empty.");
        }
    }

    private String readLine(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine();
    }

    // throws declares that this method may pass an IOException to its caller.
    private void loadStudents() {
        Path path = Paths.get(DATA_FILE);
        if (!Files.exists(path)) return;

        // try-with-resources automatically closes the file reader.
        try (BufferedReader reader = Files.newBufferedReader(path)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("\\|", -1);
                if (fields.length != 4) continue;

                try {
                    int id = Integer.parseInt(fields[0]);
                    String name = fields[1];
                    String email = fields[2];
                    double marks = Double.parseDouble(fields[3]);
                    validateStudent(id, name, email, marks);

                    if (!studentsById.containsKey(id) && !registeredEmails.contains(email)) {
                        Student student = new Student(id, name, email, marks);
                        students.add(student);
                        studentsById.put(id, student);
                        registeredEmails.add(email);
                    }
                } catch (RuntimeException ignored) {
                    System.out.println("Skipped an invalid record in the data file.");
                }
            }
        } catch (IOException e) {
            System.out.println("Could not load saved records: " + e.getMessage());
        }
    }

    private void saveStudents() throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(
                Paths.get(DATA_FILE),
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING,
                StandardOpenOption.WRITE)) {
            for (Student student : students) {
                writer.write(student.getId() + "|" + student.getName() + "|"
                        + student.getEmail() + "|" + student.getMarks());
                writer.newLine();
            }
        }
    }

    // Inner class representing one student.
    private static class Student {
        private final int id;
        private String name;
        private String email;
        private double marks;

        Student(int id, String name, String email, double marks) {
            this.id = id;
            this.name = name;
            this.email = email;
            this.marks = marks;
        }

        int getId() { return id; }
        String getName() { return name; }
        String getEmail() { return email; }
        double getMarks() { return marks; }
        void setName(String name) { this.name = name; }
        void setEmail(String email) { this.email = email; }
        void setMarks(double marks) { this.marks = marks; }

        @Override
        public String toString() {
            return id + "\t" + name + "\t\t" + email + "\t" + marks;
        }
    }

    // Custom checked exception.
    private static class StudentNotFoundException extends Exception {
        StudentNotFoundException(String message) {
            super(message);
        }
    }
}
